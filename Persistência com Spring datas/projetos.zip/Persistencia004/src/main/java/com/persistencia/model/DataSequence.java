package com.persistencia.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "data_sequences")
public class DataSequence {
	@Id
    public String id;
    public Integer atual;
}

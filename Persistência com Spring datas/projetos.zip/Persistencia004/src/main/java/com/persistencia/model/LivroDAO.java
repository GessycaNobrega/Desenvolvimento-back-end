package com.persistencia.model;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface LivroDAO extends MongoRepository<Livro,Integer>{

}

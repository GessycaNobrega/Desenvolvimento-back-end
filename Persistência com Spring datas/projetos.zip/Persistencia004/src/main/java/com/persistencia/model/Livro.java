package com.persistencia.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "livros")
public class Livro {
	
	@Transient
    public static final String SEQUENCE_NAME = "livro_sequence";
	
	@Id
	public Integer id;
	public String isbn;
	public String nome;
	public Integer ano;
	public String editora;
	public List<String> autores = new ArrayList<>();

}


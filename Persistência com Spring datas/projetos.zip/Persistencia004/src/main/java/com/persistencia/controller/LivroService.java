package com.persistencia.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.persistencia.model.DataSequenceService;
import com.persistencia.model.Livro;
import com.persistencia.model.LivroDAO;

@RestController
@EnableTransactionManagement
public class LivroService {
  @Autowired
  LivroDAO dao;
  
  @Autowired
  DataSequenceService seqService;

  @DeleteMapping("/livro/{id}")
  public void remover(@PathVariable(value="id") Integer id) {
     dao.deleteById(id); 
  }
  @PutMapping("/livro")
  public void alterar(@RequestBody Livro livro) {
     dao.save(livro); 
  }
  @PostMapping("/livro")
  public void incluir(@RequestBody Livro livro) {
     livro.id = seqService.getValor(Livro.SEQUENCE_NAME);
     dao.save(livro);
  }
  @GetMapping("/livro")
  public List<Livro> obterTodos(){
     return dao.findAll();
  }
  @GetMapping("/livro/{id}")
  public Livro obter(@PathVariable(value="id") Integer id){
     return dao.findById(id).get();
  }
}


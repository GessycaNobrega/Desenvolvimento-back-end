package com.persistencia.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.persistencia.model.Produto;
import com.persistencia.model.ProdutoDAO;

@Controller
@RequestMapping("/web/produtos")
@EnableTransactionManagement
public class ProdutoWebController {

   @Autowired
   ProdutoDAO dao;

   @RequestMapping(value = "/dadosProduto", 
                   method = RequestMethod.GET)
   public ModelAndView dadosProduto() {
      return new ModelAndView("dadosProduto", "produto", 
                              new Produto());
   }
   @RequestMapping(value = "/dadosProduto/{codigo}", 
                   method = RequestMethod.GET)
   public ModelAndView dadosProduto(
		  @PathVariable(value = "codigo") Integer codigo) {
      return new ModelAndView("dadosProduto", "produto", 
                              dao.findById(codigo).get());
   }
   @RequestMapping(value = "/dadosProduto", 
                   method = RequestMethod.POST)
   public String salvarProduto(
          @ModelAttribute Produto produto, ModelMap model) {
      dao.save(produto);
      model.addAttribute("produtos", dao.findAll());
      return "listaProdutos";
   }
   @RequestMapping(value = "/removeProduto", 
                   method = RequestMethod.GET)
   public String delProduto(
          @RequestParam(name = "codigo") Integer codigoProduto, 
          ModelMap model) {
      dao.deleteById(codigoProduto);
      model.addAttribute("produtos", dao.findAll());
      return "listaProdutos";
   }
   @RequestMapping(value = "/listaProdutos", 
                   method = RequestMethod.GET)
   public String listaProdutos(ModelMap model) {
      model.addAttribute("produtos", dao.findAll());
      return "listaProdutos";
   }
}


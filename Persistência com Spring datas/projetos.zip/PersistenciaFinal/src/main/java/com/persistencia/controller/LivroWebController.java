package com.persistencia.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.persistencia.service.LivroClient;

@Controller
@RequestMapping("/web/livro")
public class LivroWebController {

	private LivroClient livroc = new LivroClient();
	
	@GetMapping("listar")
	public String obterLivros(Model model) {
		model.addAttribute("livros", livroc.obterLivros());
		return "livroListagem";
	}
	
}

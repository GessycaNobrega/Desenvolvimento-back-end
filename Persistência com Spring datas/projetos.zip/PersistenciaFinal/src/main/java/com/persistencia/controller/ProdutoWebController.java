package com.persistencia.controller;

import java.util.Comparator;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.persistencia.model.Produto;
import com.persistencia.service.ProdutoClient;

@Controller
@RequestMapping("/web/produto")
public class ProdutoWebController {
	
	private ProdutoClient prodc = new ProdutoClient();
	
	private List<Produto> obterOrdenado(){
		List<Produto> lista = prodc.obterProdutos();
		lista.sort(new Comparator<Produto>() {
			@Override
			public int compare(Produto o1, Produto o2) {
				return o1.getNome().compareToIgnoreCase(o2.getNome());
			}});
		return lista;
	}
	
	@GetMapping("listar")
	public String obterProdutos(Model model) {
		model.addAttribute("produtos", obterOrdenado());
		return "produtoListagem";
	}
	
	@GetMapping("excluir/{codigo}")
	public String excluirProduto(
		          @PathVariable("codigo") Integer codigo, Model model) {
		String mensagem = (prodc.excluirProduto(codigo))?
				"Produto excluído com sucesso":"Erro na exclusão";
		if(prodc.obterProduto(codigo)!=null)
		   mensagem = "A exclusão não é possível quando há movimentos";
		model.addAttribute("mensagem", mensagem);
		model.addAttribute("produtos", obterOrdenado());
		return "produtoListagem";
	}
	
	private String execSalvar(Produto produto, boolean incluir, Model model) {
		boolean sucesso = (incluir)?
				prodc.incluirProduto(produto):
				prodc.alterarProduto(produto.getCodigo(), produto);
		String mensagem = (sucesso)?
				"Dados armazenados com sucesso":"Erro ao salvar os dados";
		model.addAttribute("mensagem", mensagem);
		model.addAttribute("produtos", obterOrdenado());
		return "produtoListagem";
	}
	
	@PostMapping("salvar")
	public String salvarProduto(
		          @ModelAttribute Produto produto, Model model) {
		return execSalvar(produto, true, model);
	}

	@PostMapping("salvar/{codigo}")
	public String salvarProduto(
			      @PathVariable("codigo") Integer codigo,
		          @ModelAttribute Produto produto, Model model) {
		return execSalvar(produto, true, model);
	}
	
	@GetMapping("incluir")
	public ModelAndView incluirDados() {
		return new ModelAndView("produtoDados", "produto", new Produto());
	}
	
	@GetMapping("alterar/{codigo}")
	public ModelAndView alterarDados(
			            @PathVariable("codigo") Integer codigo) {
		return new ModelAndView("produtoDados", "produto", prodc.obterProduto(codigo));
	}

}

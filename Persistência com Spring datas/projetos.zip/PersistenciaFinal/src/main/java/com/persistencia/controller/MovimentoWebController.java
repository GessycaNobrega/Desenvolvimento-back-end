package com.persistencia.controller;

import java.util.Comparator;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.persistencia.model.Movimento;
import com.persistencia.model.MovimentoVO;
import com.persistencia.service.ProdutoClient;

@Controller
@RequestMapping("/web/produto/movimento")
public class MovimentoWebController {
	
	private ProdutoClient prodc = new ProdutoClient();
	
	private List<Movimento> obterOrdenado(Integer codigo){
		List<Movimento> lista = prodc.obterMovimentos(codigo);
		lista.sort(new Comparator<Movimento>() {
			@Override
			public int compare(Movimento o1, Movimento o2) {
				return o2.dia.compareTo(o1.dia);
			}});
		return lista;
	}
	
	@GetMapping("listar/{codigo}")
	public String obterMovimentos(
			      @PathVariable("codigo") Integer codigo, Model model) {
		model.addAttribute("produto", prodc.obterProduto(codigo));
		model.addAttribute("movimentos", obterOrdenado(codigo));
		return "movimentoListagem";
	}
	
	@PostMapping("salvar/{codigo}")
	public String salvarMovimento(
			      @PathVariable("codigo") Integer codigo, 
			      @RequestParam("quantidade") Integer quantidade, 
			      @RequestParam("tipo") Character tipo, Model model) {
		MovimentoVO movimento = new MovimentoVO();
		movimento.codigo = codigo;
		movimento.quantidade = quantidade;
		movimento.tipo = tipo;
		movimento.sucesso = false; // Verificar padrão
		MovimentoVO resultado = prodc.incluirMovimento(movimento);
		String mensagem = (resultado.sucesso)?
				"Movimentação efetuada":"Erro na movimentação";
		model.addAttribute("mensagem", mensagem);
		return obterMovimentos(codigo,model);
	}
	
	@GetMapping("excluir/{codigo}/{id}")
	public String excluirMovimento(
			      @PathVariable("codigo") Integer codigo, 
			      @PathVariable("id") Integer id, Model model) {
		MovimentoVO resultado = prodc.excluirMovimento(codigo,id);
		String mensagem = (resultado.sucesso)?
				"Exclusão efetuada":"Erro na exclusão";
		model.addAttribute("mensagem", mensagem);
		return obterMovimentos(codigo,model);
	}

}

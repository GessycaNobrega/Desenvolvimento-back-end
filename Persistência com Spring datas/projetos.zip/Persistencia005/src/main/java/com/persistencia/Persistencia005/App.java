package com.persistencia.Persistencia005;

import java.util.Arrays;

import com.persistencia.model.Livro;
import com.persistencia.service.LivroClient;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        LivroClient cliente = new LivroClient();
        Livro novo = new Livro();
        novo.nome = "Operating System Concepts";
        novo.ano = 2020;
        novo.autores = Arrays.asList("Abraham Silberschatz","Greg Gagne");
        //cliente.incluirLivro(novo);
        for(Livro laux: cliente.obterLivros()) {
            System.out.println("Livro: "+ laux.id+" :: "+ laux.nome);
              	for(String s: laux.autores)
              		System.out.println("\tAutor: "+s);
        }
    }
}

package com.persistencia.model;

import java.util.Date;

public class Movimento {
	public Integer id;
	public Integer quantidade;
	public Character tipo;
	public Date dia;
}

package com.persistencia.model;

public class MovimentoVO {
  public Integer codigo;
  public Integer quantidade;
  public Character tipo;
  public Boolean sucesso = true;
}

package com.persistencia.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.persistencia.model.Movimento;
import com.persistencia.model.MovimentoDAO;
import com.persistencia.model.Produto;
import com.persistencia.model.ProdutoDAO;

@RestController
@EnableTransactionManagement
public class MovimentoService {
  @Autowired
  ProdutoDAO prodDAO;
  @Autowired
  MovimentoDAO dao;
	
  @GetMapping("/movimento/{cod_prod}")
  public List<Movimento> obterMovimentos(
         @PathVariable(value="cod_prod") Integer codigo){
    return prodDAO.findById(codigo).get().getMovimentos();
  }

  @PostMapping("/movimento")
  public MovimentoVO incluirMovimento(
         @RequestBody MovimentoVO dados){
    Produto produto = prodDAO.findById(dados.codigo).get();
    if((dados.tipo=='S')&&(dados.quantidade>produto.getQuantidade()))
      dados.sucesso=false;
    else {
      dados.sucesso=true;
	  produto.setQuantidade(produto.getQuantidade()+
			                dados.quantidade*(dados.tipo=='S'?-1:1));
      Movimento movimento = new Movimento();
      movimento.setDia(new Date());
      movimento.setProduto(produto);
      movimento.setQuantidade(dados.quantidade);
      movimento.setTipo(dados.tipo);
      prodDAO.save(produto);
      dao.save(movimento);
    }
    return dados;
  }

  @DeleteMapping("/movimento/{cod_prod}/{id_mov}")
  public MovimentoVO excluirMovimento(
         @PathVariable(value="cod_prod") Integer codigo,
         @PathVariable(value="id_mov") Integer id){
    Produto produto = prodDAO.findById(codigo).get();
    Movimento movimento = dao.findById(id).get();

    MovimentoVO dados = new MovimentoVO();
    dados.codigo = codigo;
    dados.quantidade = movimento.getQuantidade();
    dados.tipo = movimento.getTipo();
	  
    if((dados.tipo=='E')&&(produto.getQuantidade()<dados.quantidade))
      dados.sucesso = false;
    else {
      produto.setQuantidade(produto.getQuantidade()- 
    		                dados.quantidade*(dados.tipo=='S'?-1:1));
      prodDAO.save(produto);
      dao.deleteById(id);
      dados.sucesso = true;
    }
    return dados;
  }
}


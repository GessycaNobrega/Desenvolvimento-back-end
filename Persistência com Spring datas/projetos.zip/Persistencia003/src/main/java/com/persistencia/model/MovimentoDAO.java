package com.persistencia.model;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MovimentoDAO 
       extends JpaRepository<Movimento, Integer> {
}

package com.persistencia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Persistencia003Application {

	public static void main(String[] args) {
		SpringApplication.run(Persistencia003Application.class, args);
	}

}

package com.persistencia.controller;

public class MovimentoVO {
  public Integer codigo;
  public Integer quantidade;
  public Character tipo;
  public Boolean sucesso = true;
}

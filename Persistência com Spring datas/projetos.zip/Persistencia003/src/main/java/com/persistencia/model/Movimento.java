package com.persistencia.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.TableGenerator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler", "produto" })
public class Movimento {
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "idGen")
	@TableGenerator(name = "idGen", table = "TAB_IDS")
	private Integer id;

	@ManyToOne
	@JoinColumn(name = "codigo")
	private Produto produto;

	private Integer quantidade;
	private Character tipo;
	private Date dia;

	// Getters e Setters
	public Integer getId() { return id;	}
	public void setId(Integer id) { this.id = id; }
	public Produto getProduto() { return produto; }
	public void setProduto(Produto produto) { this.produto = produto; }
	public Integer getQuantidade() { return quantidade; }
	public void setQuantidade(Integer quantidade) { this.quantidade = quantidade; }
	public Character getTipo() { return tipo; }
	public void setTipo(Character tipo) { this.tipo = tipo;	}
	public Date getDia() { return dia;	}
	public void setDia(Date dia) { this.dia = dia; }
}

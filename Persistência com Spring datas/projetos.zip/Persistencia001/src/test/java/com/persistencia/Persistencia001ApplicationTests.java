package com.persistencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Persistencia001ApplicationTests {

	@Test
	void contextLoads() {
	}

}
